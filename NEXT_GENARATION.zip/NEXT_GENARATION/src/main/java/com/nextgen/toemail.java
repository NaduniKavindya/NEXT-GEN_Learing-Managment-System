package com.nextgen;



public class toemail {
	public static void main(String email)  {
		
		send_email.sendMail(email);
	
		
	}
	
	
	
}