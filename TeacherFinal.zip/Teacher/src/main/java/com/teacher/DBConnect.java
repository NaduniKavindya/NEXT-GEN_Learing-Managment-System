package com.teacher;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {

	private static String url = "jdbc:postgresql://localhost:5432/student_management";
	private static String userName = "postgres";
	private static String password = "123456";
	private static Connection con;

	public static Connection getConnection() {
		
		try {
			
			Class.forName("org.postgresql.Driver");
			
			con = DriverManager.getConnection(url, userName, password);
			
		}
		catch (Exception e) {
			System.out.println("Database connection is not success!!!");
		}
		
		return con;
	}
	
}
